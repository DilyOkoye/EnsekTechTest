﻿using EnsekTechTest.Interface.Contracts;
using EnsekTechTest.Interface.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EnsekTechTest.Business.Tests.Mocks
{

    /// <summary>The MeterReadings repository.</summary>
    public class MockMeterReadingsRepository : IMeterReadingsRepository
    {
        public IMeterReadings MeterReadings { get; set; }


        /// <summary>The get async.</summary>
        /// <returns>The <see cref="Task"/>.</returns>
        public Task<IEnumerable<IMeterReadings>> GetAsync()
        {
            throw new NotImplementedException();
        }

        /// <summary>The get async.</summary>
        /// <param name="id">The id.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        public Task<IMeterReadings> GetAsync(long id)
        {
            return Task.FromResult(this.MeterReadings);
        }

        /// <summary>The get by guid async.</summary>
        /// <param name="guid">The guid.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        public Task<IMeterReadings> GetByGuidAsync(string guid)
        {
            throw new NotImplementedException();
        }

        /// <summary>The add async.</summary>
        /// <param name="instance">The instance.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        public Task<IMeterReadings> AddAsync(IMeterReadings instance)
        {
            return Task.FromResult(instance);
        }

        /// <summary>The update async.</summary>
        /// <param name="instance">The instance.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        public Task<IMeterReadings> UpdateAsync(IMeterReadings instance)
        {
            throw new NotImplementedException();
        }

        /// <summary>The delete async.</summary>
        /// <param name="id">The id.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        public Task<bool> DeleteAsync(long id)
        {
            throw new NotImplementedException();
        }

        /// <summary>The get by merchant account id.</summary>
        /// <param name="merchantAccountId">The merchant account id.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        public Task<IMeterReadings> GetMeterReadingByAccountIdAsync(long accountId)
        {
            return Task.FromResult(this.MeterReadings);
        }
    }
}
