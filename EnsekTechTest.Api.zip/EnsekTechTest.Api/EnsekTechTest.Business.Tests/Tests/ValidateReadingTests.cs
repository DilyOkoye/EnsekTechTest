﻿using EnsekTechTest.Business.Contracts;
using EnsekTechTest.Business.factories;
using EnsekTechTest.Business.Helpers;
using EnsekTechTest.Business.Tests.Mocks;
using Microsoft.AspNetCore.Http;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace EnsekTechTest.Business.Tests.Tests
{

    /// <summary>Thevalidate meter reading tests.</summary>
    [TestFixture]
    public class ValidateReadingTests
    {
        /// <summary>The session service.</summary>
        private IValidateReadings validateReading;

        /// <summary>The mook account repository.</summary>
        private MockAccountsRepository accountsRepository;

        /// <summary>The meter reading  repository.</summary>
        private MockMeterReadingsRepository meterReadingsRepository;

        /// <summary>The object factory.</summary>
        private IObjectFactory objectFactory;


        /// <summary>The set up.</summary>
        [SetUp]
        public void SetUp()
        {
            this.accountsRepository = new MockAccountsRepository();
            this.meterReadingsRepository = new MockMeterReadingsRepository();
            this.objectFactory = new ObjectFactory();
            this.validateReading = new ValidateReadings(this.accountsRepository, this.meterReadingsRepository, this.objectFactory);
        }

        [Test]
        public async Task ValidateCsvUpload()
        {
            string extension = "pdf";
            IFormFile requestFile = Utility.GetFileMock("text/pdf", $"AccountId,MeterReadingDateTime,MeterReadValue 2344, {Utility.GenerateRandomDate()},{Utility.GenerateRandomMeterReading()}", extension);
            var result = await this.validateReading.ValidateMeterReading(requestFile);
            Assert.That(result.FailedMeterReading, Is.EqualTo(0));
        }


        [Test]
        public void CheckIfMeterReadingNumber_Success()
        {
            // Arrange
            string value = "24544";

            // Act
            var response = NumericHelper.CheckReadingNumberFormat(value);

            // Assert
            Assert.IsTrue(true);
            Assert.IsNotNull(response);
        }


        [Test]
        public void CheckIfNumericFailure()
        {
            // Arrange
            string value = "XXXX";

            // Act
            var response = NumericHelper.CheckReadingNumberFormat(value);

            // Assert
            Assert.That(response, Is.EqualTo(false));
            Assert.IsNotNull(response);
        }


        [Test]
        public void GenerateRandomMeterReadingSuccess()
        {
            var result = Utility.GenerateRandomMeterReading();
            Assert.Pass();
            Assert.IsNotNull(result);
        }


        [Test]
        public void GenerateRandomDate()
        {
            var result = Utility.GenerateRandomDate();
            Assert.Pass();
            Assert.IsNotNull(result);
        }

    }
}
