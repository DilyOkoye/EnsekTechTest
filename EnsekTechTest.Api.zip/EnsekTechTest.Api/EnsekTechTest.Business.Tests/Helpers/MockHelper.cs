﻿using AutoFixture;
using EnsekTechTest.Business.Concretes;
using EnsekTechTest.Business.Tests.Templates;
using EnsekTechTest.Interface.Repositories;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnsekTechTest.Business.Tests.Helpers
{
    /// <summary>The mock helper.</summary>
    public static class MockHelper
    {
        /// <summary>The fixture.</summary>
        private static readonly Fixture Fixture;

        /// <summary>Initializes static members of the <see cref="MockHelper"/> class.</summary>
        static MockHelper()
        {
            Fixture = new Fixture();
        }


        /// <summary>The get account repository mock.</summary>
        /// <returns>The <see cref="IAccountsRepository"/>.</returns>
        public static IAccountsRepository GetAccountsRepositoryMock()
        {
            var accounts = Fixture.Create<Accounts>();

            var accountsRepositoryMock = new Mock<IAccountsRepository>();
            accountsRepositoryMock.Setup(_ => _.AddAsync(It.IsAny<Accounts>())).ReturnsAsync(accounts);
            accountsRepositoryMock.Setup(_ => _.GetByAccountIdAsync(It.IsAny<string>())).ReturnsAsync(accounts);
            return accountsRepositoryMock.Object;
        }

        /// <summary>The get meter reading repository mock.</summary>
        /// <returns>The <see cref="IMeterReadingsRepository"/>.</returns>
        public static IMeterReadingsRepository GetMeterReadingsRepositoryMock()
        {
            var meterReadings = Fixture.Create<MeterReadings>();

            var meterReadingsRepositoryMock = new Mock<IMeterReadingsRepository>();
            meterReadingsRepositoryMock.Setup(_ => _.AddAsync(It.IsAny<MeterReadings>())).ReturnsAsync(meterReadings);
            meterReadingsRepositoryMock.Setup(_ => _.GetMeterReadingByAccountIdAsync(It.IsAny<long>())).ReturnsAsync(meterReadings);
            return meterReadingsRepositoryMock.Object;
        }
    }
}
