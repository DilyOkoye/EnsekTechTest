﻿using EnsekTechTest.Business.Concretes;
using EnsekTechTest.Interface.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnsekTechTest.Business.Tests.Templates
{
   
    /// <summary>The account tamplates.</summary>
    public static class AccountsTemplate
    {
        /// <summary>Initializes static members of the <see cref="AccountsTemplate"/> class.</summary>
        static AccountsTemplate()
        {
            accts = new Accounts { AccountId = "2344", FirstName = "Dili", LastName = "Okoye"};
        }

        /// <summary>Gets or sets the gbp.</summary>
        public static IAccounts accts { get; set; }
    }
}
