﻿using EnsekTechTest.Business.Concretes;
using EnsekTechTest.Interface.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnsekTechTest.Business.Tests.Templates
{
  

    public static class MeterReadingsTemplate
    {
        /// <summary>Initializes static members of the <see cref="MeterReadings"/> class.</summary>
        static MeterReadingsTemplate()
        {
            readings = new MeterReadings { AccountId = "2344", MeterReadingId = 24452, ReadingDate = DateTime.Now,ReadingValue =45754 };
        }

        /// <summary>Gets or sets the gbp.</summary>
        public static IMeterReadings readings { get; set; }
    }
}


