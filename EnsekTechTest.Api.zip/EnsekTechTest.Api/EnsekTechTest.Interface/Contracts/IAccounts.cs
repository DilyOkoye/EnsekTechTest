﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnsekTechTest.Interface.Contracts
{
    /// <summary>An abstract implementation of the accounts entity.</summary>
    public interface IAccounts
    {
        public int Id { get; set; }
        public string AccountId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
