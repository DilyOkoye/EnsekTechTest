﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnsekTechTest.Interface.Contracts
{
    public interface IMeterReadings
    {
        public string AccountId { get; set; }
        public DateTime? ReadingDate { get; set; }
        public long ReadingValue { get; set; }
        public long MeterReadingId { get; set; }
    }
}
