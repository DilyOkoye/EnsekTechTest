﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EnsekTechTest.Interface.Repositories
{
    /// <summary>An abstract implementation of the repository interface.</summary>
    /// <typeparam name="T">The type.</typeparam>
    public interface IRepository<T>
    {
        /// <summary>The get method, returns all instances of T from repository.</summary>
        /// <returns>The <see cref="Task"/>.</returns>
        Task<IEnumerable<T>> GetAsync();

        /// <summary>The get, returns an instance of T with the specified ID.</summary>
        /// <param name="id">The id.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        Task<T> GetAsync(long id);


        /// <summary>The add method, adds an instance of T to the repository.</summary>
        /// <param name="instance">The instance to add to the repository.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        Task<T> AddAsync(T instance);

        /// <summary>The update method, updates an instance of T in the repository.</summary>
        /// <param name="instance">The instance to update in the repository.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        Task<T> UpdateAsync(T instance);

        /// <summary>The delete method, deletes an instance of T in the repository.</summary>
        /// <param name="id">The identifier of the instance in the repository.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        Task<bool> DeleteAsync(long id);
    }
}
