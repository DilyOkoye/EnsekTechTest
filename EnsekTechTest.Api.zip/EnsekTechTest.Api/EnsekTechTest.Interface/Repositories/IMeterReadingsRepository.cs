﻿using EnsekTechTest.Interface.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EnsekTechTest.Interface.Repositories
{

    public interface IMeterReadingsRepository : IRepository<IMeterReadings>
    {
        /// <summary>Used to retrieve account details</summary>
        /// <param name="accountId">The account id.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        Task<IMeterReadings> GetMeterReadingByAccountIdAsync(long accountId);
    }
}
