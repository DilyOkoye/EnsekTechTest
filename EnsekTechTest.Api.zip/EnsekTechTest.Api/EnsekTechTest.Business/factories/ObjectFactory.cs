﻿using EnsekTechTest.Business.Concretes;
using EnsekTechTest.Business.Contracts;
using EnsekTechTest.Business.DTOs;
using EnsekTechTest.Interface.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnsekTechTest.Business.factories
{
    /// <summary>Factory for creating instances of different objects.</summary>
    public class ObjectFactory : IObjectFactory
    {
       
        public IMeterReadings CreateMeterReading(string accountId, DateTime readingDate, string readingValue)
        {
            return new MeterReadings
            {
                AccountId = accountId,
                ReadingDate = readingDate,
                ReadingValue =Convert.ToInt64(readingValue),
            };
        }

        public ResponseMeterReadingDto CreateResponseMeterReadingDto(int successfulReadings, int totalReadings)
        {
            return new ResponseMeterReadingDto
            {
                SuccessfulMeterReading = successfulReadings,
                FailedMeterReading = totalReadings - successfulReadings
            };

        }

    }
}
