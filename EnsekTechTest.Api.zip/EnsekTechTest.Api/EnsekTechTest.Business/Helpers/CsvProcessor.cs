﻿using EnsekTechTest.Business.DTOs;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace EnsekTechTest.Business.Helpers
{
   public class CsvProcessor
    {
        public static DataTable CsvToDataTable(IFormFile requestFile)
        {
            DataTable dt = new DataTable();
            if (!requestFile.FileName.EndsWith(".csv"))
            {
                return null;
            }
            try
            {
                using (var sreader = new StreamReader(requestFile.OpenReadStream()))
                {
                    dt.Columns.AddRange(new DataColumn[4] { new DataColumn("AccountId", typeof(string)),
                    new DataColumn("ReadingDate", typeof(string)),
                    new DataColumn("ReadingValue",typeof(string)),
                    new DataColumn("Empty",typeof(string))
                });

                    while (!sreader.EndOfStream)              
                    {
                        dt.Rows.Add();
                        int i = 0;
                        foreach (string cell in sreader.ReadLine().Split(','))
                        {
                            dt.Rows[dt.Rows.Count - 1][i] = cell;
                            i++;
                        }
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw;
            }

        }
        
    }
}
