﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace EnsekTechTest.Business.Helpers
{
    public static class NumericHelper
    {
        /// <summary>Convert an integer to a double using the exponent value.</summary>
        /// <param name="integer">The integer.</param>
        /// <param name="exponent">The exponent.</param>
        /// <returns>The <see cref="double"/>.</returns>
        public static bool CheckReadingNumberFormat(string value)
        {
            int i = 0;
            bool resp = int.TryParse(value, out i);
            if (resp) 
            {
                Regex regex = new Regex(@"^\d{5}$");
                return regex.IsMatch(i.ToString());
            }
            return false;
        }
    }
}