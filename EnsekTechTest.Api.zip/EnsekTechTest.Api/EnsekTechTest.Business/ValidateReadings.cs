﻿using EnsekTechTest.Business.Concretes;
using EnsekTechTest.Business.Contracts;
using EnsekTechTest.Business.DTOs;
using EnsekTechTest.Business.Helpers;
using EnsekTechTest.Interface.Repositories;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace EnsekTechTest.Business
{
    public class ValidateReadings : IValidateReadings
    {
        /// <summary>The account repository.</summary>
        private readonly IAccountsRepository accountsRepository;

        /// <summary>The account repository.</summary>
        private readonly IMeterReadingsRepository meterReadingsRepository;

        /// <summary>The object factory.</summary>
        private readonly IObjectFactory objectFactory;

        /// <summary>Initializes a new instance of the <see cref="ValidateReadings"/> class.</summary>
        /// <param name="accountsRepository">The accounts Repository.</param>
        /// <param name="meterRepository">The meter reading Repository.</param>
        public ValidateReadings(
            IAccountsRepository accountsRepository,
            IMeterReadingsRepository meterReadingsRepository,
             IObjectFactory objectFactory)
        {
            this.accountsRepository = accountsRepository;
            this.meterReadingsRepository = meterReadingsRepository;
            this.objectFactory = objectFactory;
        }

        public async Task<ResponseMeterReadingDto> ValidateMeterReading(IFormFile requestFile)
        {
                int successfulReadings = 0;
                List<MeterReadings> meterReadings = new List<MeterReadings>();
                List<RequestMeterReadingDto> requestMeterReadingDto = new List<RequestMeterReadingDto>();
            try
            {
                var dt = CsvProcessor.CsvToDataTable(requestFile);
                if (dt != null && dt.Rows.Count > 0)
                {
                    // remove first item of the upload
                    dt.Rows.Remove(dt.Rows[0]);

                    requestMeterReadingDto = dt.AsEnumerable().Select(m => new RequestMeterReadingDto()
                    {
                        AccountId = m.Field<string>("AccountId") == null ? "" : m.Field<string>("AccountId").Trim(),
                        ReadingDate = m.Field<string>("ReadingDate") == null ? (DateTime?)null : DateTime.Parse(m.Field<string>("ReadingDate").Trim()),
                        ReadingValue = m.Field<string>("ReadingValue") == null ? "" : m.Field<string>("ReadingValue").Trim(),
                    }).ToList();

                    if (requestMeterReadingDto.Count() > 0)
                    {
                        foreach (var item in requestMeterReadingDto)
                        {
                            var account = await this.accountsRepository.GetByAccountIdAsync(item.AccountId);
                            if (account != null)
                            {
                                var uniqeMeterReading = requestMeterReadingDto.Where(o => o.AccountId == account.AccountId
                                && NumericHelper.CheckReadingNumberFormat(o.ReadingValue) == true)
                                .OrderByDescending(o => o.ReadingDate).FirstOrDefault();

                                if (uniqeMeterReading != null)
                                {
                                    // Build creation of meter reading object
                                    var readings = this.objectFactory.CreateMeterReading(uniqeMeterReading.AccountId, (DateTime)uniqeMeterReading.ReadingDate, uniqeMeterReading.ReadingValue);

                                    // Add meter reading to repository
                                    var result = await this.meterReadingsRepository.AddAsync(readings);
                                    if (result.MeterReadingId != 0)
                                    {

                                        successfulReadings++;

                                    }
                                }

                            }

                        }

                    }
                }


                var responseSessionDto =
                                this.objectFactory.CreateResponseMeterReadingDto(successfulReadings, requestMeterReadingDto.Count());

                return responseSessionDto;
            }
            catch (Exception ex)
            {

                throw;
            }

        }

    }
}
