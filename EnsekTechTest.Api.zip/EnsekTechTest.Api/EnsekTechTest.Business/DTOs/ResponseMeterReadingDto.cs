﻿using EnsekTechTest.Business.Concretes;
using System;
using System.Collections.Generic;

namespace EnsekTechTest.Business.DTOs
{
    public class ResponseMeterReadingDto
    {
        public int SuccessfulMeterReading { get; set; }

        public int FailedMeterReading { get; set; }

    }
}
