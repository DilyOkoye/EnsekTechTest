﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnsekTechTest.Business.DTOs
{
    public class RequestMeterReadingDto
    {
        public string AccountId { get; set; }
        public DateTime? ReadingDate { get; set; }
        public string ReadingValue { get; set; }
    }
}
