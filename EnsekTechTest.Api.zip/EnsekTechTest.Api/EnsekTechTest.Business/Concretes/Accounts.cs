﻿using EnsekTechTest.Interface.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnsekTechTest.Business.Concretes
{
    public class Accounts : IAccounts
    {
        public int Id { get; set; }
        public string AccountId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
