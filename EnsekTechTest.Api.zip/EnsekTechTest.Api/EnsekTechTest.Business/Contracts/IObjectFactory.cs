﻿using EnsekTechTest.Business.Concretes;
using EnsekTechTest.Business.DTOs;
using EnsekTechTest.Interface.Contracts;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EnsekTechTest.Business.Contracts
{
    public interface IObjectFactory
    {

        IMeterReadings CreateMeterReading(string accountId, DateTime readingDate, string readingValue);

        ResponseMeterReadingDto CreateResponseMeterReadingDto(int successfulReadings, int totalReadings);
    }
}
