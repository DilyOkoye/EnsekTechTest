﻿using EnsekTechTest.Business.DTOs;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EnsekTechTest.Business.Contracts
{
    public interface IValidateReadings
    {
        Task<ResponseMeterReadingDto> ValidateMeterReading(IFormFile requestFile);
    }
}
