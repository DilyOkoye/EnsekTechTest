﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/
MERGE INTO [tbl_Accounts] AS Target
USING (VALUES
(1, '2344', 'Tommy','Test'),
(2, '2233', 'Barry','Test'),
(3, '8766', 'Sally','Test'),
(4, '2345', 'Jerry','Test'),
(5, '2346', 'Ollie','Test'),
(6, '2347', 'Tara','Test'),
(7, '2348', 'Tammy','Test'),
(8, '2349', 'Simon','Test'),
(9, '2350', 'Colin','Test'),
(10, '2351', 'Gladys','Test'),
(11, '2352', 'Greg','Test'),
(12, '2353', 'Tony','Test'),
(13, '2355', 'Arthur','Test'),
(14, '2356', 'Craig','Test'),
(15, '6776', 'Laura','Test'),
(16, '4534', 'JOSH','TEST'),
(17, '1234', 'Freya','Test'),
(18, '1239', 'Noddy','Test'),
(19, '1240', 'Archie','Test'),
(20, '1241', 'Lara','Test'),
(21, '1242', 'Tim','Test'),
(22, '1243', 'Graham','Test'),
(23, '1244', 'Tony','Test'),
(24, '1245', 'Neville','Test'),
(25, '1246', 'Jo','Test'),
(26, '1247', 'Jim','Test'),
(27, '1248', 'Pam','Test')
)
AS Source ([Id], [AccountId], [FirstName],[LastName])
ON Target.[Id] = [Source].[Id]
-- Update matched
WHEN MATCHED THEN
	UPDATE SET [AccountId] = Source.[AccountId], [FirstName] = Source.[FirstName], [LastName] = Source.[LastName]
-- Insert new
WHEN NOT MATCHED BY Target THEN
	INSERT ([Id], [AccountId], [FirstName],[LastName])
	VALUES ([Id], [AccountId], [FirstName],[LastName])
-- Delete if not in Source
WHEN NOT MATCHED BY Source
	THEN DELETE;