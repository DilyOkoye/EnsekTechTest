﻿CREATE PROCEDURE [dbo].[uspGetAccountById]
	@Id INT
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		
		SELECT
			[Id],
			[AccountId],
			[FirstName],
			[LastName]
		FROM [tbl_Accounts] 
		WHERE [Id] = @Id

	END TRY
	BEGIN CATCH

		;THROW

	END CATCH
END
GO


