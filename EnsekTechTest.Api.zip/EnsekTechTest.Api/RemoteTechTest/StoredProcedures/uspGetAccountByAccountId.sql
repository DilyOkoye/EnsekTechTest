﻿CREATE PROCEDURE [dbo].[uspGetAccountByAccountId]
	@AccountId varchar(50)
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		
		SELECT
			[Id],
			[AccountId],
			[FirstName],
			[LastName]
		FROM [tbl_Accounts] 
		WHERE [AccountId] = @AccountId

	END TRY
	BEGIN CATCH

		;THROW

	END CATCH
END
GO


