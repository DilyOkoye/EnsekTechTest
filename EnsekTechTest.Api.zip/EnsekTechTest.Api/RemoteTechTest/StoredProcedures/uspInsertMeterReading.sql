﻿CREATE PROCEDURE [dbo].[uspInsertMeterReading]
	@AccountId VARCHAR(50),
	@ReadingDate datetime,	
	@ReadingValue bigint,
	@MeterReadingId BIGINT OUTPUT	
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY

	    DECLARE @ps_AccountId varchar(50);
		DECLARE @ps_ReadingDate DateTime;
		DECLARE @ps_ReadingValue bigint;
		
		SELECT @ps_AccountId =[AccountId],@ps_ReadingDate =[ReadingDate],@ps_ReadingValue =[ReadingValue]
		FROM [tbl_MeterReading] 
		WHERE [AccountId] = @AccountId --and [ReadingDate] =@ReadingDate and [ReadingValue] =@ReadingValue

		IF @ps_AccountId IS NOT NULL
		BEGIN

			IF @ReadingDate > @ps_ReadingDate
			BEGIN
			update [tbl_MeterReading] 
			SET [ReadingDate] =@ReadingDate
			Where [AccountId] = @AccountId 
			END

			ELSE IF  @ReadingValue <> @ps_ReadingValue
			BEGIN
			update [tbl_MeterReading] 
			SET [ReadingValue] =@ReadingValue
			Where [AccountId] = @AccountId 
			END

			ELSE
			BEGIN
			SELECT @MeterReadingId = 0
		     RETURN(0)
			END
		
		SELECT @MeterReadingId =1
		RETURN(1)

		END


		INSERT INTO [tbl_MeterReading] 
			([AccountId]
			,[ReadingDate]           
			,[ReadingValue])
		VALUES 
			(@AccountId
			,@ReadingDate
			,@ReadingValue)

		SELECT @MeterReadingId = SCOPE_IDENTITY()

		RETURN(0)

	END TRY
	BEGIN CATCH

		;THROW

	END CATCH
END
GO


