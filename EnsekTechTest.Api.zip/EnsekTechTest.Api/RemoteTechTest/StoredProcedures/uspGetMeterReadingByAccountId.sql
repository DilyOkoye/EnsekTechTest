﻿CREATE PROCEDURE [dbo].[uspGetMeterReadingByAccountId]
	@AccountId INT
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		
		SELECT
			[Id],
			[AccountId],
			[ReadingDate],
			[ReadingValue]
		FROM [tbl_MeterReading] 
		WHERE [AccountId] = @AccountId

	END TRY
	BEGIN CATCH

		;THROW

	END CATCH
END