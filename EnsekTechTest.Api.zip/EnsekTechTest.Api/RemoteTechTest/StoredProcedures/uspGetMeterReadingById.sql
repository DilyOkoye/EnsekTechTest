﻿CREATE PROCEDURE [dbo].[uspGetMeterReadingById]
	@Id INT
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRY
		
		SELECT
			[Id],
			[AccountId],
			[ReadingDate],
			[ReadingValue]
		FROM [tbl_MeterReading] 
		WHERE [Id] = @Id

	END TRY
	BEGIN CATCH

		;THROW

	END CATCH
END
GO


