﻿
CREATE TABLE [dbo].[tbl_MeterReading](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[AccountId] [varchar](50) NULL,
	[ReadingDate] [datetime] NOT NULL,
	[ReadingValue] [bigint] NOT NULL
) ON [PRIMARY]
GO


