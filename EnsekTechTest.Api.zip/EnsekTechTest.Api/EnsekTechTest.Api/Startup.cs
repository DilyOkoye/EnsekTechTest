using EnsekTechTest.Api.Concretes.Configurations;
using EnsekTechTest.Api.Contracts.Configurations;
using EnsekTechTest.Api.OperationFilters;
using EnsekTechTest.Business;
using EnsekTechTest.Business.Contracts;
using EnsekTechTest.Interface.Repositories;
using EnsekTechTest.Repository.Concretes;
using EnsekTechTest.Repository.Contexts;
using EnsekTechTest.Repository.Contracts;
using EnsekTechTest.Repository.Factories;
using EnsekTechTest.Repository.Mappers;
using EnsekTechTest.Repository.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using ObjectFactory = EnsekTechTest.Business.factories.ObjectFactory;

namespace EnsekTechTest.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddSwaggerGen();

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc(
                    "v1",
                    new OpenApiInfo
                    {
                        Title = "Ensek Tech Test API",
                        Version = "v1",
                        Description = "Ensek Tech test to upload and analyse Meter Reading",
                        Contact = new OpenApiContact
                        {
                            Name = "Developed by Dilichukwu Okoye",
                            Email = "mdeeokoye@gmail.com",
                        },
                    });

                options.OperationFilter<IdentityHeaderOperationFilter>();
                options.OperationFilter<MacHeaderOperationFilter>();

            });

            services.Configure<ApiBehaviorOptions>(options => { options.SuppressModelStateInvalidFilter = true; });
            this.AddConfigurationsToServiceCollection(services);
            this.AddRepositoriesToServiceCollection(services);
            this.AddFactoriesToServiceCollection(services);
            this.AddMappersToServiceCollection(services);
            this.AddContextsToServiceCollection(services);
            this.AddServicesToServiceCollection(services);
        }

        /// <summary>Adds entity mappers to the service collection and injects them where they are required.</summary>
        /// <param name="serviceCollection">The service collection.</param>
        private void AddMappersToServiceCollection(IServiceCollection serviceCollection)
        {
            serviceCollection.AddSingleton<IDataReaderMapper<Accounts>, AccountsMapper>();
            serviceCollection.AddSingleton<IDataReaderMapper<MeterReadings>, MeterReadingsMapper>();
 
        }

        /// <summary>Adds services to the service collection and injects them where they are required.</summary>
        /// <param name="serviceCollection">The service collection.</param>
        private void AddServicesToServiceCollection(IServiceCollection serviceCollection)
        {
            serviceCollection.AddTransient<IValidateReadings, ValidateReadings>();
           
        }

        /// <summary>Adds contexts to the service collection and injects them where they are required.</summary>
        /// <param name="serviceCollection">The service collection.</param>
        private void AddContextsToServiceCollection(IServiceCollection serviceCollection)
        {
            serviceCollection.AddTransient<IDbContext, DbContext>();
        }

        /// <summary>Adds repositories to the service collection and injects them where they are required.</summary>
        /// <param name="serviceCollection">The service collection.</param>
        private void AddRepositoriesToServiceCollection(IServiceCollection serviceCollection)
        {
            serviceCollection.AddTransient<IAccountsRepository, AccountsRepository>();
            serviceCollection.AddTransient<IMeterReadingsRepository, MeterReadingsRepository>();
           
        }

        /// <summary>Adds factories to the service collection and injects them where they are required.</summary>
        /// <param name="serviceCollection">The service collection.</param>
        private void AddFactoriesToServiceCollection(IServiceCollection serviceCollection)
        {
            serviceCollection.AddTransient<IAdoDatabaseCommandFactory, AdoDatabaseCommandFactory>();
            serviceCollection.AddSingleton<IObjectFactory, ObjectFactory>();
        }

       
        /// <summary>
        ///     Adds relevant configuration from the application settings to the
        ///     service collection so the settings can be injected into where they
        ///     are required.
        /// </summary>
        /// <param name="serviceCollection">The service collection which stored the dependencies.</param>
        private void AddConfigurationsToServiceCollection(IServiceCollection serviceCollection)
        {


            ISecurityConfiguration securityConfiguration = new SecurityConfiguration();
            this.Configuration.Bind("SecurityConfiguration", securityConfiguration);
            serviceCollection.AddSingleton(securityConfiguration);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {

                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseSwagger();
            app.UseSwaggerUI(options => options.SwaggerEndpoint("./v1/swagger.json", "Ensek Tech Test API"));

            app.Run(context => {
                context.Response.Redirect("swagger");
                return Task.CompletedTask;
            });
        }
    }
}
