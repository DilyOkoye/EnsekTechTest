﻿using EnsekTechTest.Api.Filters;
using EnsekTechTest.Business.Contracts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace EnsekTechTest.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [SecurityFilter]
    public class MeterReadingUploadController : ControllerBase
    {
       
        private readonly ILogger<MeterReadingUploadController> _logger;

        /// <summary>The implementation of validate reading which acts as a facade to delegate requests to.</summary>
        private readonly IValidateReadings validateReadings;

        public MeterReadingUploadController(IValidateReadings validateReadings, ILogger<MeterReadingUploadController> logger)
        {
            _logger = logger;
            this.validateReadings = validateReadings;
        }

        [HttpPost("MeterReadingUploads")]
        [ProducesResponseType((int)HttpStatusCode.Created)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType((int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult> MeterReadingUploads(IFormFile file)
        {
            if (!file.FileName.EndsWith(".csv"))
            {
                return this.StatusCode((int)HttpStatusCode.BadRequest, "File Type Should be a Csv");
            }

            var result = await this.validateReadings.ValidateMeterReading(file);
            return this.Created(string.Empty, result);
        }

      
    }
}

