﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace EnsekTechTest.Repository.Contracts
{
    /// <summary>An abstract implementation of a database context.</summary>
    public interface IDbContext
    {
        /// <summary>Sets the connection string to run the commands against.</summary>
        /// <param name="connectionStringKey">The key of the connection string within the configuration.</param>
        /// <returns>The <see cref="IDbContext"/>.</returns>
        IDbContext SetConnectionString(string connectionStringKey);

        /// <summary>Adds a parameter to the command which is to be executed.</summary>
        /// <param name="paramName">The parameter name.</param>
        /// <param name="paramValue">The parameter value.</param>
        /// <returns>The <see cref="IDbContext"/>.</returns>
        IDbContext AddParameter(string paramName, object paramValue);

        /// <summary>Adds a return parameter to the command which is to be executed.</summary>
        /// <param name="paramName">The parameter name.</param>
        /// <param name="sqlDbType">The structured query language database type.</param>
        /// <param name="size">The size of the return parameter.</param>
        /// <returns>The <see cref="IDbContext"/>.</returns>
        IDbContext AddReturnParameter(string paramName, SqlDbType sqlDbType, int? size = null);

        /// <summary>Sets the stored procedure name which is to be executed.</summary>
        /// <param name="storedProcedureName">The command to be run.</param>
        /// <returns>The <see cref="IDbContext"/>.</returns>
        IDbContext SetStoredProcedureName(string storedProcedureName);

        /// <summary>Asynchronously executes a non query against the underlying database.</summary>
        /// <returns>The <see cref="Task"/>.</returns>
        Task ExecuteNonQueryAsync();

        /// <summary>Asynchronously executes a query with a return value against the underlying database.</summary>
        /// <returns>The <see cref="Task"/>.</returns>
        Task<List<SqlParameter>> ExecuteReturnQueryAsync();


        /// <summary>Asynchronously executes a query which returns a scalar against the database.</summary>
        /// <returns>The <see cref="Task"/>.</returns>
        Task<object> ExecuteScalarAsync();

        /// <summary>Asynchronously executes a query with a reader against the database.</summary>
        /// <param name="func">A delegate which maps an IDataReader to the type specified.</param>
        /// <typeparam name="T">The type to be created from the query.</typeparam>
        /// <returns>The <see cref="Task"/>.</returns>
        Task<List<T>> ExecuteReaderAsync<T>(Func<IDataReader, T> func)
            where T : new();
    }
}
