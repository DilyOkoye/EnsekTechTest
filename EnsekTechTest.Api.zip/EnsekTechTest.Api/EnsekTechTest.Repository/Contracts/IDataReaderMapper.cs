﻿using System.Data;

namespace EnsekTechTest.Repository.Contracts
{
    /// <summary>An abstract implementation of a data reader mapper.</summary>
    /// <typeparam name="T">The type to map from.</typeparam>
    public interface IDataReaderMapper<out T>
    {
        /// <summary>Used to map from a type to another type.</summary>
        /// <param name="dataReader">The data reader to map to other type.</param>
        /// <returns>The <see><cref>T</cref></see>.</returns>
        T Map(IDataReader dataReader);
    }
}
