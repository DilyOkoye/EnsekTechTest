﻿using EnsekTechTest.Repository.Concretes;
using System.Data;
using System.Data.SqlClient;


namespace EnsekTechTest.Repository.Contracts
{
    /// <summary>An abstract implementation of an object that creates instances of a database command object.</summary>
    public interface IAdoDatabaseCommandFactory
    {
        /// <summary>Adds a return parameter value with the command.</summary>
        /// <param name="name">The name of the return parameter.</param>
        /// <param name="sqlDbType">The type of the return parameter.</param>
        /// <param name="size">The size of the return parameter.</param>
        void AddReturnParameter(string name, SqlDbType sqlDbType, int? size = null);

        /// <summary>Adds a parameter command being built.</summary>
        /// <param name="paramName">The parameter name.</param>
        /// <param name="paramValue">The parameter value.</param>
        void AddParameter(string paramName, object paramValue);

        /// <summary>Creates a command with the given database connection.</summary>
        /// <param name="sqlConnection">The structured query language connection.</param>
        /// <returns>The <see cref="IDbCommand"/>.</returns>
        CreateCommandResult Create(SqlConnection sqlConnection);

        /// <summary>Sets the stored procedure name to be run to the command.</summary>
        /// <param name="storedProcedureName">The stored procedure name.</param>
        void SetStoredProcedureName(string storedProcedureName);
    }
}
