﻿using System.Data;

namespace EnsekTechTest.Repository.Contracts
{
    /// <summary>An abstract implementation of a return parameter entity.</summary>
    public interface IReturnParameter
    {
        /// <summary>Gets or sets the Id.</summary>
        string Id { get; set; }

        /// <summary>Gets or sets the Type.</summary>
        SqlDbType Type { get; set; }

        /// <summary>Gets or sets the Size.</summary>
        int? Size { get; set; }
    }
}
