﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace EnsekTechTest.Repository.Concretes
{
    /// <summary>Encapsulates the result of create command on the ado database command factory.</summary>
    public class CreateCommandResult
    {
        /// <summary>Gets or sets the structured query language command.</summary>
        public SqlCommand SqlCommand { get; set; }

        /// <summary>Gets or sets the return parameters.</summary>
        public List<SqlParameter> ReturnParameters { get; set; }
    }
}
