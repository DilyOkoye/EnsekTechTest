﻿using EnsekTechTest.Interface.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace EnsekTechTest.Repository.Concretes
{
    public class MeterReadings:  IMeterReadings
    {
        public int? Id { get; set; }
        public string AccountId { get; set; }
        public DateTime? ReadingDate { get; set; }
        public long ReadingValue { get; set; }

        public long MeterReadingId { get; set; }
    }
}
