﻿using EnsekTechTest.Repository.Contracts;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace EnsekTechTest.Repository.Concretes
{
    public class ReturnParameter : IReturnParameter
    {
        /// <summary>Gets or sets the Id.</summary>
        public string Id { get; set; }

        /// <summary>Gets or sets the Type.</summary>
        public SqlDbType Type { get; set; }

        /// <summary>Gets or sets the Size.</summary>
        public int? Size { get; set; }
    }
}
