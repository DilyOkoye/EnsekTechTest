﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace EnsekTechTest.Repository.Extensions
{
    /// <summary>A class to encapsulate structured query language extension methods.</summary>
    public static class SqlExtensions
    {
        /// <summary>Extension method to retrieve the value from a data reader instance from the specified column.</summary>
        /// <param name="dataReader">The data reader.</param>
        /// <param name="columnName">The column name.</param>
        /// <typeparam name="T">The type to be returned.</typeparam>
        /// <returns>The <see><cref>T</cref></see>.</returns>
        public static T GetColumnValueOrDefault<T>(this IDataReader dataReader, string columnName)
        {
            if (dataReader == null)
            {
                return default(T);
            }

            var columnIndex = dataReader.GetOrdinal(columnName);

            if (dataReader.IsDBNull(columnIndex))
            {
                return default(T);
            }

            /*
             * Works out if the type is nullable, if it is retrieve it's non-nullable type equivalent
             * and use the non nullable type to do the conversion as ChangeType does not work with
             * nullable types, we also know at this point that the database value is not null because
             * of the check above.
             */
            var conversionType = typeof(T);
            var nullableUnderlyingType = Nullable.GetUnderlyingType(conversionType);

            return nullableUnderlyingType == null
                       ? (T)Convert.ChangeType(dataReader.GetValue(columnIndex), conversionType)
                       : (T)Convert.ChangeType(dataReader.GetValue(columnIndex), nullableUnderlyingType);
        }
    }
}
