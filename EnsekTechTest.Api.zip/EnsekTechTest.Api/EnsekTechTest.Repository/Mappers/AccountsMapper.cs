﻿using EnsekTechTest.Repository.Concretes;
using EnsekTechTest.Repository.Contracts;
using EnsekTechTest.Repository.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace EnsekTechTest.Repository.Mappers
{
  
    public class AccountsMapper : IDataReaderMapper<Accounts>
    {
        /// <param name="dataReader">The data reader.</param>
        /// <returns>The <see cref="Accounts"/>.</returns>
        public Accounts Map(IDataReader dataReader)
        {
            return new Accounts
            {
                Id = dataReader.GetColumnValueOrDefault<int>("Id"),
                AccountId = dataReader.GetColumnValueOrDefault<string>("AccountId"),
                FirstName = dataReader.GetColumnValueOrDefault<string>("FirstName"),
                LastName = dataReader.GetColumnValueOrDefault<string>("LastName"),
             
            };
        }
    }
}
