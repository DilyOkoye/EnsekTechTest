﻿using EnsekTechTest.Repository.Concretes;
using EnsekTechTest.Repository.Contracts;
using EnsekTechTest.Repository.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace EnsekTechTest.Repository.Mappers
{
   
    public class MeterReadingsMapper : IDataReaderMapper<MeterReadings>
    {
        /// <param name="dataReader">The data reader.</param>
        /// <returns>The <see cref="Accounts"/>.</returns>
        public MeterReadings Map(IDataReader dataReader)
        {
            return new MeterReadings
            {
                Id = dataReader.GetColumnValueOrDefault<int>("Id"),
                AccountId = dataReader.GetColumnValueOrDefault<string>("AccountId"),
                ReadingDate = dataReader.GetColumnValueOrDefault<DateTime>("ReadingDate"),
                ReadingValue = dataReader.GetColumnValueOrDefault<long>("ReadingValue"),

            };
        }
    }
}
