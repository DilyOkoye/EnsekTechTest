﻿using EnsekTechTest.Repository.Contracts;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace EnsekTechTest.Repository.Contexts
{
    /// <summary>A database context to communicate with databases.</summary>
    public class DbContext : IDbContext
    {
        /// <summary>Used to retrieve configuration for the connection strings.</summary>
        private readonly IConfiguration configuration;

        /// <summary>Used to create instances of a command object.</summary>
        private readonly IAdoDatabaseCommandFactory adoDatabaseCommandFactory;

        /// <summary>The connection string of the underlying database.</summary>
        private string connectionString;

        /// <summary>Initializes a new instance of the <see cref="DbContext"/> class.</summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="adoDatabaseCommandFactory">The ado database command factory.</param>
        public DbContext(IConfiguration configuration, IAdoDatabaseCommandFactory adoDatabaseCommandFactory)
        {
            this.configuration = configuration;
            this.adoDatabaseCommandFactory = adoDatabaseCommandFactory;
        }

        /// <summary>The set connection string.</summary>
        /// <param name="connectionStringName">The connection string name.</param>
        /// <returns>The <see cref="IDbContext"/>.</returns>
        public IDbContext SetConnectionString(string connectionStringName)
        {
            this.connectionString = this.configuration.GetConnectionString(connectionStringName);
            return this;
        }

        /// <summary>Adds a parameter to the command to be executed.</summary>
        /// <param name="paramName">The parameter name.</param>
        /// <param name="paramValue">The parameter value.</param>
        /// <returns>The <see cref="IDbContext"/>.</returns>
        public IDbContext AddParameter(string paramName, object paramValue)
        {
            this.adoDatabaseCommandFactory.AddParameter(paramName, paramValue);
            return this;
        }

        /// <summary>Adds a return parameter to the command which is to be executed.</summary>
        /// <param name="paramName">The parameter name.</param>
        /// <param name="sqlDbType">The structured query language database type.</param>
        /// <param name="size">The size of the return parameter.</param>
        /// <returns>The <see cref="IDbContext"/>.</returns>
        public IDbContext AddReturnParameter(string paramName, SqlDbType sqlDbType, int? size = null)
        {
            this.adoDatabaseCommandFactory.AddReturnParameter(paramName, sqlDbType, size);
            return this;
        }

        /// <summary>Sets the stored procedure name to be executed to the command.</summary>
        /// <param name="storedProcedureName">The stored procedure name.</param>
        /// <returns>The <see cref="IDbContext"/>.</returns>
        public IDbContext SetStoredProcedureName(string storedProcedureName)
        {
            this.adoDatabaseCommandFactory.SetStoredProcedureName(storedProcedureName);
            return this;
        }

        /// <summary>Asynchronously executes a query with no return value.</summary>
        /// <returns>The <see cref="Task"/>.</returns>
        public async Task ExecuteNonQueryAsync()
        {
            using (var connection = new SqlConnection(this.connectionString))
            {
                await connection.OpenAsync();

                using (var command = this.adoDatabaseCommandFactory.Create(connection).SqlCommand)
                {
                    await command.ExecuteNonQueryAsync();
                }

                await connection.CloseAsync();
            }
        }

        /// <summary>Asynchronously executes a query with a return value against the underlying database.</summary>
        /// <returns>The <see cref="Task"/>.</returns>
        public async Task<List<SqlParameter>> ExecuteReturnQueryAsync()
        {
            List<SqlParameter> result;

            using (var connection = new SqlConnection(this.connectionString))
            {
                await connection.OpenAsync();

                var createCommandResult = this.adoDatabaseCommandFactory.Create(connection);

                using (var command = createCommandResult.SqlCommand)
                {
                    await command.ExecuteNonQueryAsync();

                    result = createCommandResult.ReturnParameters;
                }

                await connection.CloseAsync();
            }

            return result;
        }

        /// <summary>Asynchronously executes a query returning a scalar value.</summary>
        /// <returns>The <see cref="Task"/>.</returns>
        public async Task<object> ExecuteScalarAsync()
        {
            object result;

            using (var connection = new SqlConnection(this.connectionString))
            {
                await connection.OpenAsync();

                using (var command = this.adoDatabaseCommandFactory.Create(connection).SqlCommand)
                {
                    result = await command.ExecuteScalarAsync();
                }

                await connection.CloseAsync();
            }

            return result;
        }

        /// <summary>Asynchronously executes a command and returns the list of results.</summary>
        /// <param name="func">A delegate to be used to map objects from IDataReader to the type specified.</param>
        /// <typeparam name="T">The type.</typeparam>
        /// <returns>The <see cref="Task"/>.</returns>
        public async Task<List<T>> ExecuteReaderAsync<T>(Func<IDataReader, T> func)
            where T : new()
        {
            var result = new List<T>();

            using (var connection = new SqlConnection(this.connectionString))
            {
                await connection.OpenAsync();

                using (var command = this.adoDatabaseCommandFactory.Create(connection).SqlCommand)
                {
                    var reader = await command.ExecuteReaderAsync();

                    while (reader.Read())
                    {
                        result.Add(func(reader));
                    }

                    await reader.CloseAsync();
                }

                await connection.CloseAsync();
            }

            return result;
        }
    }
}
