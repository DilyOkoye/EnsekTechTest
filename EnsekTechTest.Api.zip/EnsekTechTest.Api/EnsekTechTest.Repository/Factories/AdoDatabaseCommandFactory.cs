﻿using EnsekTechTest.Repository.Concretes;
using EnsekTechTest.Repository.Contracts;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace EnsekTechTest.Repository.Factories
{
    public class AdoDatabaseCommandFactory : IAdoDatabaseCommandFactory
    {
        /// <summary>The stored procedure name.</summary>
        private string storedProcedureName;

        /// <summary>Indicates whether parameters have been added to the command.</summary>
        private bool parametersAdded;

        /// <summary>The parameters to be added to the query.</summary>
        private Dictionary<string, object> parameters;

        /// <summary>Indicates a return parameters have been provided for the current command.</summary>
        private bool returnParametersAdded;

        /// <summary>The return parameters to be returned from the query.</summary>
        private List<ReturnParameter> returnParameters;

        /// <summary>Adds the given parameter to the collection of parameters for the query.</summary>
        /// <param name="paramName">The parameter name.</param>
        /// <param name="paramValue">The parameter value.</param>
        public void AddParameter(string paramName, object paramValue)
        {
            if (this.parameters == null)
            {
                this.parameters = new Dictionary<string, object>();
            }

            if (paramValue == null)
            {
                paramValue = DBNull.Value;
            }

            this.parameters.Add(paramName, paramValue);
            this.parametersAdded = true;
        }

        /// <summary>Sets up a return parameter value with the command.</summary>
        /// <param name="name">The name of the return parameter.</param>
        /// <param name="sqlDbType">The type of the return parameter.</param>
        /// <param name="size">The size of the return parameter.</param>
        public void AddReturnParameter(string name, SqlDbType sqlDbType, int? size = null)
        {
            if (this.returnParameters == null)
            {
                this.returnParameters = new List<ReturnParameter>();
            }

            this.returnParameters.Add(new ReturnParameter() { Id = name, Type = sqlDbType, Size = size });
            this.returnParametersAdded = true;
        }

        /// <summary>Sets the stored procedure to run to the given name.</summary>
        /// <param name="storedProcedure">The stored Procedure.</param>
        public void SetStoredProcedureName(string storedProcedure)
        {
            this.storedProcedureName = storedProcedure;
        }

        /// <summary>Creates a command instance from the given connection.</summary>
        /// <param name="sqlConnection">The structured query language connection to be used.</param>
        /// <returns>The <see cref="IDbCommand"/>.</returns>
        public CreateCommandResult Create(SqlConnection sqlConnection)
        {
            var command = sqlConnection.CreateCommand();
            var returnParameterReferences = new List<SqlParameter>();

            command.CommandText = this.storedProcedureName;
            command.CommandType = CommandType.StoredProcedure;

            if (this.parametersAdded)
            {
                foreach (var param in this.parameters)
                {
                    var createdParam = command.CreateParameter();

                    createdParam.ParameterName = param.Key;
                    createdParam.Value = param.Value;

                    command.Parameters.Add(createdParam);
                }

                this.parameters.Clear();
                this.parametersAdded = false;
            }

            if (this.returnParametersAdded)
            {
                foreach (var returnParameter in this.returnParameters)
                {
                    var createdParam = command.CreateParameter();

                    createdParam.ParameterName = returnParameter.Id;
                    createdParam.SqlDbType = returnParameter.Type;
                    createdParam.Size = returnParameter.Size ?? default(int);
                    createdParam.Direction = ParameterDirection.Output;

                    command.Parameters.Add(createdParam);
                    returnParameterReferences.Add(createdParam);
                }

                this.returnParameters.Clear();
                this.returnParametersAdded = false;
            }

            return new CreateCommandResult { SqlCommand = command, ReturnParameters = returnParameterReferences };
        }
    }
}
