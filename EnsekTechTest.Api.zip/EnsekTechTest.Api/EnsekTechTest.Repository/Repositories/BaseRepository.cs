﻿using EnsekTechTest.Interface.Contracts;
using EnsekTechTest.Interface.Repositories;
using EnsekTechTest.Repository.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EnsekTechTest.Repository.Repositories
{
    public abstract class BaseRepository<T> : IRepository<T>
    {
        /// <summary>The connection string key.</summary>
        private const string TechTestConnectionString = "RemoteTechTest";

        /// <summary>Initializes a new instance of the <see cref="BaseRepository{T}"/> class.</summary>
        /// <param name="dbContext">The database context.</param>
        protected BaseRepository(IDbContext dbContext)
        {
            this.DbContext = dbContext;
        }

        /// <summary>Gets the database context.</summary>
        protected IDbContext DbContext { get; }

      
        /// <summary>Retrieves all the entities of type from the repository.</summary>
        /// <returns>The <see cref="Task"/>.</returns>
        public virtual Task<IEnumerable<T>> GetAsync()
        {
            throw new System.NotImplementedException();
        }

        /// <summary>Asynchronously retrieves an entity of type with the specified id from the repository.</summary>
        /// <param name="id">The id.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        public virtual Task<T> GetAsync(long id)
        {
            throw new System.NotImplementedException();
        }

        
        /// <summary>Asynchronously adds an entity of type to the repository.</summary>
        /// <param name="instance">The instance.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        public virtual Task<T> AddAsync(T instance)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>Asynchronously updates an entity of type to the repository.</summary>
        /// <param name="instance">The instance.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        public virtual Task<T> UpdateAsync(T instance)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>Asynchronously deletes an entity of type from the repository.</summary>
        /// <param name="id">The id.</param>
        /// <returns>The <see cref="Task"/>.</returns>
        public virtual Task<bool> DeleteAsync(long id)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>Retrieves the connection string key to be used with the value of the record type.</summary>
        /// <returns>The <see cref="string"/>.</returns>
        protected string RetrieveConnectionString()
        {
            return TechTestConnectionString;
        }

    }
}
