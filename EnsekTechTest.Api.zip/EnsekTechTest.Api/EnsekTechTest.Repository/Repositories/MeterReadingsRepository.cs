﻿using EnsekTechTest.Interface.Contracts;
using EnsekTechTest.Interface.Repositories;
using EnsekTechTest.Repository.Concretes;
using EnsekTechTest.Repository.Contracts;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnsekTechTest.Repository.Repositories
{
    /// <summary>Used to manipulate data within the meter reading repository.</summary>
    public class MeterReadingsRepository : BaseRepository<IMeterReadings>, IMeterReadingsRepository
    {
        /// <summary>Maps data from a data reader instance to a meter reading entity.</summary>
        private readonly IDataReaderMapper<MeterReadings> dataReaderMapper;

        public MeterReadingsRepository(IDbContext dbContext, IDataReaderMapper<MeterReadings> dataReaderMapper)
            : base(dbContext)
        {
            this.dataReaderMapper = dataReaderMapper;
        }

        
        public override async Task<IMeterReadings> GetAsync(long id)
        {
            var meterReadingList = await this.DbContext
                                      .SetConnectionString(this.RetrieveConnectionString())
                                      .SetStoredProcedureName("[uspMeterReadingById]")
                                      .AddParameter("@Id", id)
                                      .ExecuteReaderAsync(this.dataReaderMapper.Map);

            return meterReadingList.FirstOrDefault();
        }


        public async Task<IMeterReadings> GetMeterReadingByAccountIdAsync(long accountId)
        {

            var meterReadingList = await this.DbContext
                                         .SetConnectionString(this.RetrieveConnectionString())
                                         .SetStoredProcedureName("[uspGetMeterReadingByAccountId]")
                                         .AddParameter("@AccountId", accountId)
                                         .ExecuteReaderAsync(this.dataReaderMapper.Map);

            return meterReadingList.FirstOrDefault();
        }


        public override async Task<IMeterReadings> AddAsync(IMeterReadings meterReadings)
        {
            var returnParameters = await this.DbContext
                                       .SetConnectionString(this.RetrieveConnectionString())
                                       .SetStoredProcedureName("[uspInsertMeterReading]")
                                       .AddParameter("@AccountId", meterReadings.AccountId)
                                       .AddParameter("@ReadingDate", meterReadings.ReadingDate)
                                       .AddParameter("@ReadingValue", meterReadings.ReadingValue)
                                       .AddReturnParameter("@MeterReadingId", SqlDbType.BigInt)
                                       .ExecuteReturnQueryAsync();

            meterReadings.MeterReadingId = (long)returnParameters.FirstOrDefault(parameter => parameter.ParameterName == "@MeterReadingId").Value;
            return meterReadings;
        }

    }
}
