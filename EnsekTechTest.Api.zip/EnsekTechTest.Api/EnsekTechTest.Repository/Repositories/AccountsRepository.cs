﻿using EnsekTechTest.Interface.Contracts;
using EnsekTechTest.Interface.Repositories;
using EnsekTechTest.Repository.Concretes;
using EnsekTechTest.Repository.Contracts;
using System.Linq;
using System.Threading.Tasks;

namespace EnsekTechTest.Repository.Repositories
{
    /// <summary>Used to manipulate data within the accounts repository.</summary>
    public class AccountsRepository : BaseRepository<IAccounts>, IAccountsRepository
    {
        /// <summary>Maps data from a data reader instance to a accounts entity.</summary>
        private readonly IDataReaderMapper<Accounts> dataReaderMapper;

        /// <summary>Initializes a new instance of the <see cref="AccountsRepository"/> class.</summary>
        /// <param name="dbContext">The database context.</param>
        /// <param name="dataReaderMapper">The data reader mapper.</param>
        public AccountsRepository(IDbContext dbContext, IDataReaderMapper<Accounts> dataReaderMapper)
            : base(dbContext)
        {
            this.dataReaderMapper = dataReaderMapper;
        }

        /// <summary>Initializes a new instance of the <see cref="AccountsRepository"/> class.</summary>
        /// <param name="dbContext">The db context.</param>
        public AccountsRepository(IDbContext dbContext)
            : base(dbContext)
        {
        }


        public override async Task<IAccounts> GetAsync(long id)
        {
            var accountList = await this.DbContext
                                      .SetConnectionString(this.RetrieveConnectionString())
                                      .SetStoredProcedureName("[uspGetAccountById]")
                                      .AddParameter("@Id", id)
                                      .ExecuteReaderAsync(this.dataReaderMapper.Map);

            return accountList.FirstOrDefault();
        }


        public async Task<IAccounts> GetByAccountIdAsync(string accountId)
        {

            var accountList = await this.DbContext
                                         .SetConnectionString(this.RetrieveConnectionString())
                                         .SetStoredProcedureName("uspGetAccountByAccountId")
                                         .AddParameter("@AccountId", accountId)
                                         .ExecuteReaderAsync(this.dataReaderMapper.Map);

            return accountList.FirstOrDefault();
        }

    }
}
